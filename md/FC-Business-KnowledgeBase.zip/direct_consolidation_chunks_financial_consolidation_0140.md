# Chunk 140: Key Complexity Factors:

## Context

This section covers Key Complexity Factors:.

## Content

## Key Complexity Factors:
- Five entities with interconnected ownership
- Both vertical and horizontal cross-holdings
- Circular ownership loops at multiple levels


We then calculate the indirect financial percentage in each company.


---
*Chunk 140 | Key Complexity Factors:*