# Chunk 239: 6.3 How do we consolidate foreign companies?

## Context

This section covers 6.3 How do we consolidate foreign companies?.

## Content

# 6.3 How do we consolidate foreign companies?

To explain how to consolidate a foreign company, we will make the following assumptions

- We will consider the figures processed in the previous section for the foreign company named A  
We will suppose company A is owned at  80%  by a parent company P  
- Consequently, we will apply the global consolidation method, but all the principles would remain unchanged for the two other methods  
The consolidation will be done for Year 1 and Year 2  
- Only balance sheets will be consolidated.


---
*Chunk 239 | 6.3 How do we consolidate foreign companies?*