# Chunk 367: Effective Ownership:

## Context

This section covers Effective Ownership:.

## Content

## Effective Ownership:
- A: 80% by P + 20% by B (itself 60% owned by P)
- Effective P control in A: 80% + (60% × 20%) = 92%


---
*Chunk 367 | Effective Ownership:*