# Chunk 426: Key Changes:

## Context

This section covers Key Changes:.

## Content

## Key Changes:
- P increases ownership of A from 80% to 90% (+10%)
- A maintains 60% ownership of B (unchanged)


---
*Chunk 426 | Key Changes:*