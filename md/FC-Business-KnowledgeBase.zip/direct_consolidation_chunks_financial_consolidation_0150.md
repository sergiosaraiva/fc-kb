# Chunk 150: Ownership Percentage Matrix

## Context

This section contains financial statement data.

## Content

# Ownership Percentage Matrix

| From/To | P | A | B | C |
|---------|--:|--:|--:|--:|
| **P** | 0 | 0.86 | 0.6 | 0.56 |
| **A** | 0 | 0 | 0 | 0.44 |
| **B** | 0 | 0.1 | 0 | 0.24 |
| **C** | 0 | 0 | 0 | 0 |


---
*Chunk 150 | Ownership Percentage Matrix*