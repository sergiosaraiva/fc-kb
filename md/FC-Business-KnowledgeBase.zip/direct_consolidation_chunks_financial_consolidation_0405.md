# Chunk 405: Context:

## Context

This section addresses foreign currency translation.

## Content

## Context:
- Analysis of consolidated reserves evolution
- Impact of ownership percentage changes
- Companies use consolidation currency (no translation effects)
- Focus on Company B's consolidated reserves calculation


## Related Topics

- Currency translation

---
*Chunk 405 | Context:*