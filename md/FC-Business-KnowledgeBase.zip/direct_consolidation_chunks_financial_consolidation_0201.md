# Chunk 201: 5.1 The technique of stage consolidation

## Context

This section covers 5.1 The technique of stage consolidation. Discusses relationships between entities: t.

## Content

# 5.1 The technique of stage consolidation

This technique consists in consolidating each company by the company that owns the company directly and thus consolidate up step by step, from bottom to top.


---
*Chunk 201 | 5.1 The technique of stage consolidation*