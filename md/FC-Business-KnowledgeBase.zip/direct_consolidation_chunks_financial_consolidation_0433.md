# Chunk 433: Transaction Details (January 1st, Year 2):

## Context

This section covers Transaction Details (January 1st, Year 2):. Discusses relationships between entities: P, A.

## Content

## Transaction Details (January 1st, Year 2):
1. Capital increase in B: 500 (third parties not subscribing)
2. A acquires B shares: 500
3. P acquires A shares: 700


---
*Chunk 433 | Transaction Details (January 1st, Year 2):*