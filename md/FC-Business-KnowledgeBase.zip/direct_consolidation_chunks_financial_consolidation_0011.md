# Chunk 11: 3 The 1990s: The search for a miracle solution

## Context

This section covers 3 The 1990s: The search for a miracle solution.

## Content

Did unified consolidation finally fulfil its potential ten years later? There were clear convergences in functionality thanks to the comfort provided by tools increasingly in the public domain and also thanks to the expression of needs by groups which were becoming more uniform. Consolidation was bound to become a strategic planning tool rather than a simple picture of the past.


---
*Chunk 11 | 3 The 1990s: The search for a miracle solution*