# Chunk 270: 8.2 A company doesn't apply the group's rules in its statutory accounts

## Context

This section covers 8.2 A company doesn't apply the group's rules in its statutory accounts.

## Content

## 8.2 A company doesn't apply the group's rules in its statutory accounts


---
*Chunk 270 | 8.2 A company doesn't apply the group's rules in its statutory accounts*