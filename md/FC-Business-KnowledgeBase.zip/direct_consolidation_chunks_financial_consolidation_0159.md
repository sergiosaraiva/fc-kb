# Chunk 159: Ownership Details:

## Context

This section explains minority interest calculations. Discusses relationships between entities: P.

## Content

## Ownership Details:
- P owns **51%** of S (controlling interest)
- Minority interests: **49%** (100% - 51%)


## Related Topics

- Minority interests calculation

---
*Chunk 159 | Ownership Details:*