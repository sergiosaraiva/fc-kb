# Chunk 378: Restructuring Changes:

## Context

This section covers Restructuring Changes:. Discusses relationships between entities: P, B.

## Content

## Restructuring Changes:
- **Before**: P owns both A and B directly (parallel structure)
- **After**: P owns B, B owns A (chain structure)
- A moved from sister company to subsidiary of B


---
*Chunk 378 | Restructuring Changes:*