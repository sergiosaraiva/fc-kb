# Chunk 117: Structure with Treasury Shares

## Context

This section covers Structure with Treasury Shares.

## Content

# Structure with Treasury Shares

```
         ┌─────┐
      ←──│  P  │
    10%  └─┬─┬─┘
           │ │
      100%│ │80%
           │ │
           ↓ ↓
       ┌────┐ ┌────┐
       │ C1 │ │ C2 │
       └────┘ └────┘
```


---
*Chunk 117 | Structure with Treasury Shares*