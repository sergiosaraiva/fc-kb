# Chunk 404: Right Structure:

## Context

This section covers Right Structure:. Discusses relationships between entities: P, A.

## Content

### Right Structure:
- P owns 80% of A
- A owns 50% of B
- P's indirect ownership of B: 40% (80% × 50%)


---
*Chunk 404 | Right Structure:*