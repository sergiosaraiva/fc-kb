# Chunk 293: 8.6 Deferred tax adjustments

## Context

This section covers 8.6 Deferred tax adjustments.

## Content

# 8.6 Deferred tax adjustments


---
*Chunk 293 | 8.6 Deferred tax adjustments*