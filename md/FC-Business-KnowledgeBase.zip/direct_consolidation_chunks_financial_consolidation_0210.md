# Chunk 210: Key Features:

## Context

This section covers Key Features:.

## Content

## Key Features:
- Cross-participation between A and B
- B holds minority stake back in A
- Creates circular ownership structure
- Requires special consolidation treatment


---
*Chunk 210 | Key Features:*