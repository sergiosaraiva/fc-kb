# Chunk 22: BASICS OF CONSOLIDATION TECHNIQUES

## Context

This section covers BASICS OF CONSOLIDATION TECHNIQUES. Shows detailed calculations.

## Content

# BASICS OF CONSOLIDATION TECHNIQUES


<!-- Source: 3c6723dfe180d0ec9bf391828f6d40d255414fddd896c749552dae75fef4c66a.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T16:15:00 -->
<!-- Context: Part 2 - Basics of Consolidation Techniques introduction -->
<!-- Section: 1.1 Groups of companies illustration -->


---
*Chunk 22 | BASICS OF CONSOLIDATION TECHNIQUES*