# Chunk 487: Control Analysis:

## Context

This section covers the equity method for 20-50% ownership stakes.

## Content

## Control Analysis:
- T has majority control (70%)
- P has significant minority stake (30%)
- T likely consolidates A globally
- P uses equity method for A


## Related Topics

- Equity method (20-50% ownership)

---
*Chunk 487 | Control Analysis:*