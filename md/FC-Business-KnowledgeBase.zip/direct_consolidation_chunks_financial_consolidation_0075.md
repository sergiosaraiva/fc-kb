# Chunk 75: Typical Scenarios:

## Context

This section covers Typical Scenarios:.

## Content

## Typical Scenarios:
- Joint venture between three partners
- Consortium arrangement
- Strategic alliance structure


In the case of joint control, consolidation is, in principle, done via the proportional method.


---
*Chunk 75 | Typical Scenarios:*