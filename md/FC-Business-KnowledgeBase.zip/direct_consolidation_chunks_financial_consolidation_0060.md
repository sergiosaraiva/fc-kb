# Chunk 60: Key Features:

## Context

This section covers Key Features:. Key thresholds: control (>50%) triggering global integration.

## Content

## Key Features:
- Most basic consolidation structure
- Clear control (80% > 50%)
- No intermediate entities
- No cross-participations


---
*Chunk 60 | Key Features:*