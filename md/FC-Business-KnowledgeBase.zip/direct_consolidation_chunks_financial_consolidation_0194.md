# Chunk 194: Consolidation Implications:

## Context

This section describes global integration method for controlled subsidiaries.

## Content

## Consolidation Implications:
- **For Parent**: Global integration (80% control)
- **For Partner**: No consolidation (20% minority)


## Related Topics

- Global integration (>50% control)

---
*Chunk 194 | Consolidation Implications:*