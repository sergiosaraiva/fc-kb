# Chunk 488: Consolidation Methods:

## Context

This section covers the equity method for 20-50% ownership stakes.

## Content

## Consolidation Methods:
- **For T**: Global integration (70% control)
- **For P**: Equity method (30% significant influence)


## Related Topics

- Equity method (20-50% ownership)
- Global integration (>50% control)

---
*Chunk 488 | Consolidation Methods:*