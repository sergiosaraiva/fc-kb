# Chunk 47: Control Requirement:

## Context

This section describes global integration method for controlled subsidiaries. Discusses relationships between entities: P.

## Content

## Control Requirement:
- P owns more than 50% of A
- Threshold for consolidation control
- Triggers global integration method


## Related Topics

- Global integration (>50% control)

---
*Chunk 47 | Control Requirement:*