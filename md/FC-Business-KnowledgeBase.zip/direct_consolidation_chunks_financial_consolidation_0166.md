# Chunk 166: 4.2 Proportional integration method

## Context

This section covers 4.2 Proportional integration method.

## Content

## 4.2 Proportional integration method

According to the method of proportional integration, the Assets, Liabilities, Expenses and Income of a joint subsidiary are included in the consolidated financial statements in proportion to the percentage held by the parent company.


---
*Chunk 166 | 4.2 Proportional integration method*