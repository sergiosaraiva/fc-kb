# Chunk 264: The adjustments

## Context

This section contains financial statement data.

## Content

### The adjustments

It just consists in a reclassification of 20 from Purchases/A to some Other expenses account.


| H |  |
| --- | --- |
|   | Result (120)Payables/A 120 |
| Purchases/A 120(20) |   |
| Other expenses 20 |   |
| Result (120) |   |


Looking to each individual accounts, they show A having a debt of 20 with the VAT administration but it is H that recognizes the expense of 20 in its P&L accounts.

When both accounts are consolidated, we just see that the group has a debt of 20 corresponding to an expense of 20.


---
*Chunk 264 | The adjustments*