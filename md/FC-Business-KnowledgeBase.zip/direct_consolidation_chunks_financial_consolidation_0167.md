# Chunk 167: Example

## Context

This section covers Example. Includes practical examples. Shows detailed calculations.

## Content

### Example


<!-- Source: a4afd02ebd0254c39c59e25f3471a2ab0924e77e77e4cef733705ddcc586ad13.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T15:53:00 -->
<!-- Context: Proportional integration method example -->
<!-- Section: 4.2 Joint venture consolidation -->


---
*Chunk 167 | Example*