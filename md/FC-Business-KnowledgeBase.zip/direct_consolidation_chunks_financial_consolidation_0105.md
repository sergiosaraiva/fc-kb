# Chunk 105: Control Assessment:

## Context

This section covers Control Assessment:. Discusses relationships between entities: P.

## Content

## Control Assessment:
- P controls C1 (80%)
- P controls C2 (60%)
- P has significant influence in C3 (40%)
- P has indirect influence in C4 (48%)


---
*Chunk 105 | Control Assessment:*