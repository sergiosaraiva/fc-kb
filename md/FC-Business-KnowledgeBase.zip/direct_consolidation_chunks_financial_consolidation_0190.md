# Chunk 190: Example

## Context

This section covers Example. Includes practical examples. Shows detailed calculations.

## Content

### Example

In this example, parent company creates a company C with a Partner, contributing to  80%  and  20%  to the capital respectively.


<!-- Source: eafbe8954a2273c9e9ad8ffd27ddb87dcfb950f19e8b780b86ea23a1d25d3812.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T18:13:00 -->
<!-- Context: Joint ownership structure -->
<!-- Section: Shared control arrangement -->


---
*Chunk 190 | Example*