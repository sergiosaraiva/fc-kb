# Chunk 429: Situation 6 : And if all transactions were happening at the same time

## Context

This section covers Situation 6 : And if all transactions were happening at the same time. Shows detailed calculations.

## Content

## Situation 6 : And if all transactions were happening at the same time

Indeed, we can imagine all the previous transactions happening at the same time (1<sup>st</sup> of January Year 2), we mean

- Capital increase in company B for an amount of 500,  3rd  Parties not subscribing to that capital increase  
Company A acquiring shares of company B for a price of 500  
Company P acquiring shares of company A for a price of 700

Here are the group structure and the statutory accounts


<!-- Source: 3da263b683c3af0247fbe1307f23dbe43f7caac3120e963e05f6a0f518569b63.jpg -->
<!-- Type: mixed (diagram + table) -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T15:16:00 -->
<!-- Context: Situation 6 - All transactions happening simultaneously -->
<!-- Section: Complex ownership change with capital increase -->


---
*Chunk 429 | Situation 6 : And if all transactions were happening at the same time*