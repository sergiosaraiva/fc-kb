# Chunk 284: The situation

## Context

This section covers The situation.

## Content

## The situation

In most of the industrial groups, some companies are dedicated to supply on the market and make products and some other companies are dedicated to sell these products. In such situation, the normal practice for the industrial companies is to sell the products to the commercial companies, including a benefit called stocks margin. From that point of view, these transactions imply a group profit and, as was explained in the previous section, it should be eliminated. However, we will see that the set of consolidation adjustments differs from the previous one because of the stocks accounts.

For the explanation, let's consider a company A manufacturing some products and selling them to a commercial company B which, in turn, sells these products on the market. We will also suppose that each stock stays in the companies accounts for less than a year.

In Year 1, the group decides for the first time to eliminate stocks margins. Company A sells to company B some stocks for a price of 350 and initially booked for 300, making a stock margin of 50.

In Year 2, company A sells again some stocks to company B for a price of 460 and initially booked for 400, making a stocks margin of 60. The Year 1 stocks bought by company B are no longer in its accounts because sold to the market.

How do we eliminate these stocks margins?


---
*Chunk 284 | The situation*