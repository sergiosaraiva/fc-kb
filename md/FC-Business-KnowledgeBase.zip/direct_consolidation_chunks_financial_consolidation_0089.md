# Chunk 89: Key Considerations:

## Context

This section covers Key Considerations:. Discusses relationships between entities: A.

## Content

## Key Considerations:
- Legal restrictions on treasury shares
- Maximum holding limits may apply
- Impact on market capitalization
- Share buyback accounting rules


5% = 95% , and then calculate the relationship between what company A owns in company B and the recalculated percentage  \((60% / 95% = 63%)\) . The effective control power is  63% .


---
*Chunk 89 | Key Considerations:*