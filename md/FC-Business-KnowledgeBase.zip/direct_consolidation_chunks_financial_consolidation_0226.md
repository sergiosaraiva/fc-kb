# Chunk 226: Ownership Percentages:

## Context

This section covers Ownership Percentages:.

## Content

## Ownership Percentages:
- **A**: 80% (direct ownership)
- **B**: 56% (indirect: 80% × 70% from original P→A→B structure)


---
*Chunk 226 | Ownership Percentages:*