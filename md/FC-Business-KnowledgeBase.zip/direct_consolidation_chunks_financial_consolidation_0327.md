# Chunk 327: 8.12 Acquisition of a company with a badwill

## Context

This section covers 8.12 Acquisition of a company with a badwill.

## Content

## 8.12 Acquisition of a company with a badwill


## Related Topics

- Acquisition accounting

---
*Chunk 327 | 8.12 Acquisition of a company with a badwill*