# Chunk 103: Direct Ownership:

## Context

This section covers Direct Ownership:.

## Content

## Direct Ownership:
- P → C1: 80%
- P → C2: 60%
- P → C3: 40%
- C1 → C4: 30%
- C2 → C4: 20%
- C3 → C4: 20%
- C3 → C4: 10% (second path)


---
*Chunk 103 | Direct Ownership:*