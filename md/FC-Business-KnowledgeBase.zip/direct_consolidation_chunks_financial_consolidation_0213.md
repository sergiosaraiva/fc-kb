# Chunk 213: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: P, B, A.

## Content

## Ownership Structure:
- P owns 80% of A (direct)
- P owns 10% of B (direct)
- A owns 60% of B (direct)
- B owns 10% of A (cross-participation)


---
*Chunk 213 | Ownership Structure:*