# Chunk 479: Impact Analysis:

## Context

This section covers Impact Analysis:.

## Content

## Impact Analysis:
- P reduces stake in A (partial divestment)
- A increases stake in B (additional acquisition)
- Net effect: P's indirect control of B decreases
- Possible change in consolidation method for P→A


## Related Topics

- Acquisition accounting

---
*Chunk 479 | Impact Analysis:*