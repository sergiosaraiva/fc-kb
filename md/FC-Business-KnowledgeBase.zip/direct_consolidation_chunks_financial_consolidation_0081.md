# Chunk 81: Consolidation Methods:

## Context

This section covers the equity method for 20-50% ownership stakes.

## Content

## Consolidation Methods:
- **B**: Global integration by A
- **C**: Equity method (20% combined stake)


## Related Topics

- Equity method (20-50% ownership)
- Global integration (>50% control)

---
*Chunk 81 | Consolidation Methods:*