# Chunk 427: Indirect Ownership Calculations:

## Context

This section covers Indirect Ownership Calculations:. Contains formula: s indirect in B = 48% (80% × 60%).

## Content

## Indirect Ownership Calculations:
- **Year 1**: P's indirect in B = 48% (80% × 60%)
- **Year 2**: P's indirect in B = 54% (90% × 60%)


---
*Chunk 427 | Indirect Ownership Calculations:*