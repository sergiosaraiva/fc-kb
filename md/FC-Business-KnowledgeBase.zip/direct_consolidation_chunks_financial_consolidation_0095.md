# Chunk 95: Typical Applications:

## Context

This section covers elimination entries in consolidation. Includes practical examples. Shows detailed calculations.

## Content

## Typical Applications:
- Most common group structure
- Clear governance model
- Simple reporting lines
- Standard elimination procedures


In more general group structures, subsidiaries can have participations in other subsidiaries, as in the following example


<!-- Source: 2105bf26cad627f1c0e2d53dafc065d9525ce26439fbd734cea83d618c1cceef.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T17:14:00 -->
<!-- Context: Horizontal chain structure -->
<!-- Section: Linear three-company chain -->


## Related Topics

- Elimination entries

---
*Chunk 95 | Typical Applications:*