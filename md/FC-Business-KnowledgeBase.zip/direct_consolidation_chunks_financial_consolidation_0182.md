# Chunk 182: Key Information:

## Context

This section covers Key Information:.

## Content

## Key Information:
- Investment in S recorded at: 120
- Total assets (including investment): 1,150
- Balance sheet balances: 1,150 = 1,150 ✓


---
*Chunk 182 | Key Information:*