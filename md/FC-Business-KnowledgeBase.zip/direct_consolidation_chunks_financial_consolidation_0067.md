# Chunk 67: Key Features:

## Context

This section explains minority interest calculations.

## Content

## Key Features:
- High ownership percentages
- Strong control throughout chain
- Relatively small minority interests
- Clear consolidation path


## Related Topics

- Minority interests calculation

---
*Chunk 67 | Key Features:*