# Chunk 118: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: P.

## Content

## Ownership Structure:
- P owns 100% of C1
- P owns 80% of C2
- C1 owns 10% of P (treasury shares situation)


---
*Chunk 118 | Ownership Structure:*