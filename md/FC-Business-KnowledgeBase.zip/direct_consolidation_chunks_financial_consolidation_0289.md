# Chunk 289: 8.5 Leasing not booked in balance sheet

## Context

This section covers 8.5 Leasing not booked in balance sheet.

## Content

# 8.5 Leasing not booked in balance sheet


---
*Chunk 289 | 8.5 Leasing not booked in balance sheet*