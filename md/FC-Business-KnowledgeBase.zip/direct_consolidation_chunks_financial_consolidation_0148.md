# Chunk 148: Paths to C:

## Context

This section covers Paths to C:.

## Content

## Paths to C:
- Via A: 80% × 40% = 32%
- Via B directly: 60% × 20% = 12%
- Cross-effect via B→A→C: Complex calculation
- **Combined P's interest in C**: ~44% (after iterations)


---
*Chunk 148 | Paths to C:*