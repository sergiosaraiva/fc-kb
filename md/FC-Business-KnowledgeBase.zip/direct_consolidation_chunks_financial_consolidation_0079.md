# Chunk 79: Combined Ownership in C:

## Context

This section covers Combined Ownership in C:.

## Content

## Combined Ownership in C:
- Direct from A: 8%
- Indirect via B: 12% (80% × 15%)
- Total A's interest: 20% (8% + 12%)


---
*Chunk 79 | Combined Ownership in C:*