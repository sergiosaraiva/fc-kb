# Chunk 184: Company S - Balance Sheet

## Context

This section contains financial statement data.

## Content

# Company S - Balance Sheet

| **S** | | | |
|-------|------:|------------|------:|
| | | Capital | 200 |
| | | Reserves | [value] |
| | | Result | [value] |
| Assets | 700 | Liabilities | 300 |
| **Total** | **700** | **Total** | **700** |


---
*Chunk 184 | Company S - Balance Sheet*