# Chunk 100: Minority Interests:

## Context

This section explains minority interest calculations.

## Content

## Minority Interests:
- In A: 20%
- In B: 52% (100% - 48%)


## Related Topics

- Minority interests calculation

---
*Chunk 100 | Minority Interests:*