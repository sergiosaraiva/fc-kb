# Chunk 248: 7.1 Some important principles about intercompany matching

## Context

This section covers 7.1 Some important principles about intercompany matching.

## Content

## 7.1 Some important principles about intercompany matching


---
*Chunk 248 | 7.1 Some important principles about intercompany matching*