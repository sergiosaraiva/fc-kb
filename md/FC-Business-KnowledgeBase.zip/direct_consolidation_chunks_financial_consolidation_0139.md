# Chunk 139: Control Assessment:

## Context

This section covers Control Assessment:. Discusses relationships between entities: P.

## Content

## Control Assessment:
- P controls C1 (75% direct despite C4's 35%)
- P controls C2 (80% direct + indirect via C3)
- P influences C3 (30% significant influence)
- Indirect control of C4 and C5 through subsidiaries


---
*Chunk 139 | Control Assessment:*