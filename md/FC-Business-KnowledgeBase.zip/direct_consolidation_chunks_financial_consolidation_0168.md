# Chunk 168: Joint Venture Structure - Proportional Integration

## Context

This section covers Joint Venture Structure - Proportional Integration.

## Content

# Joint Venture Structure - Proportional Integration

```
    ┌─────┐                    ┌─────┐
    │  P  │───────50%──────────→│  S  │
    └─────┘                    └─────┘
```


---
*Chunk 168 | Joint Venture Structure - Proportional Integration*