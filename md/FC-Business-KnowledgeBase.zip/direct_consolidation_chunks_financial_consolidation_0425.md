# Chunk 425: Year 2

## Context

This section covers Year 2.

## Content

## Year 2
```
    ┌─────┐
    │  P  │
    └──┬──┘
       │ 90%
       ↓
    ┌─────┐
    │  A  │
    └──┬──┘
       │ 60%
       ↓
    ┌─────┐
    │  B  │
    └─────┘
```


---
*Chunk 425 | Year 2*