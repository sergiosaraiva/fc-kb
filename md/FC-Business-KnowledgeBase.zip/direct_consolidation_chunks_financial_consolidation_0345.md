# Chunk 345: Method 1: Statutory view versus Consolidation view

## Context

This section covers Method 1: Statutory view versus Consolidation view.

## Content

which is exactly the same as the one we got in the previous method.


---
*Chunk 345 | Method 1: Statutory view versus Consolidation view*