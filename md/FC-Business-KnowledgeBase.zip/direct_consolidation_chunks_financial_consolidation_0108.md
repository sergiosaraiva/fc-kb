# Chunk 108: 3.4 Some groups with more complex structures

## Context

This section covers 3.4 Some groups with more complex structures. Contains formula: md ========== -->. Includes practical examples. Discusses relationships between entities: B, A.

## Content

## 3.4 Some groups with more complex structures

By complex structures, we basically think of following both situations

- Company A owns shares of company B and company B owns shares of company A. We than speak about 'crossed participations"  
- Company A owns shares of the parent company.

Let's consider each of these two situations on the basis of an example.

<!-- ========== CHUNK 5: DOC0038_pages_5_251127_152730.md ========== -->


---
*Chunk 108 | 3.4 Some groups with more complex structures*