# Chunk 63: Linear Chain with High Ownership

## Context

This section covers Linear Chain with High Ownership.

## Content

# Linear Chain with High Ownership

```
    ┌─────┐         ┌─────┐         ┌─────┐
    │  A  │───75%──→│  B  │───90%──→│  C  │
    └─────┘         └─────┘         └─────┘
```


---
*Chunk 63 | Linear Chain with High Ownership*