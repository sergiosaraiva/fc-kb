# Chunk 152: Direct Holdings:

## Context

This section covers Direct Holdings:.

## Content

## Direct Holdings:
- P → A: 86%
- P → B: 60%
- P → C: 56%
- A → C: 44%
- B → A: 10% (cross-participation)
- B → C: 24%


---
*Chunk 152 | Direct Holdings:*