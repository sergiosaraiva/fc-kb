# Chunk 158: Global Integration Method - Controlling Interest

## Context

This section describes global integration method for controlled subsidiaries.

## Content

# Global Integration Method - Controlling Interest

```
    ┌─────┐                    ┌─────┐
    │  P  │───────51%──────────→│  S  │
    └─────┘                    └─────┘
```


## Related Topics

- Global integration (>50% control)

---
*Chunk 158 | Global Integration Method - Controlling Interest*