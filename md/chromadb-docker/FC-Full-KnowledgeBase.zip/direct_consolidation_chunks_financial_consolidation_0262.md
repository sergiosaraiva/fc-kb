# Chunk 262: Unmatched intercompany transactions because of non deductible VAT

## Context

This section covers Unmatched intercompany transactions because of non deductible VAT.

## Content

## Unmatched intercompany transactions because of non deductible VAT


---
*Chunk 262 | Unmatched intercompany transactions because of non deductible VAT*