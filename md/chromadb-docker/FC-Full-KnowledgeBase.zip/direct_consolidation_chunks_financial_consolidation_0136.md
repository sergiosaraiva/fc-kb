# Chunk 136: Ownership Structure:

## Context

This section covers Ownership Structure:.

## Content

## Ownership Structure:
- **P's direct holdings**: C1 (75%), C2 (80%), C3 (30%)
- **C1**: owns C4 (25%)
- **C2**: owns C5 (35%)
- **C3**: owns C2 (7% - cross-participation)
- **C4**: owns C1 (35% - circular) and C5 (25%)


---
*Chunk 136 | Ownership Structure:*