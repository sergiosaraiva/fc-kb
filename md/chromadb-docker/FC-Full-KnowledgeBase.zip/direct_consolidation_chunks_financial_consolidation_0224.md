# Chunk 224: Direct Consolidation - "Rake" Structure

## Context

This section covers Direct Consolidation - "Rake" Structure.

## Content

# Direct Consolidation - "Rake" Structure

```
         ┌─────┐
         │  P  │
         └──┬──┘
           /│\
        80%/ │ \56%
         /   │   \
        ↓    │    ↓
    ┌─────┐ │  ┌─────┐
    │  A  │ │  │  B  │
    └─────┘ │  └─────┘
```


---
*Chunk 224 | Direct Consolidation - "Rake" Structure*