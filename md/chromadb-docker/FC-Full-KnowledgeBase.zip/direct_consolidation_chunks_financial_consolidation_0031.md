# Chunk 31: 1.2 Financial consolidation statements

## Context

This section covers 1.2 Financial consolidation statements.

## Content

Both approaches were considered, none gives satisfaction. How to associate to a group of companies a significant, homogeneous economic picture as if the group was considered itself as a unique company dealing only with the outside world?

These deficiencies led the financial world to develop a new technique of 'valuation' of groups, basic rules of which are universally adopted today: the consolidation of accounts.


---
*Chunk 31 | 1.2 Financial consolidation statements*