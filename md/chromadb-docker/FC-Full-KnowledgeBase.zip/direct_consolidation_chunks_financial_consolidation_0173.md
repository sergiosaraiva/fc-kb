# Chunk 173: Explanation

## Context

This section describes global integration method for controlled subsidiaries.

## Content

Again, we start with the statutory accounts of each companies and then

Column P (1) eliminates the investments in P accounts, just as we did for the global integration method

- Column S (2) eliminates the  50%  of Assets, Liabilities, Income and Expenses which cannot be integrated in the consolidated accounts  
- Column S (3) eliminates the  50%  of equity and reclassify the total amount on the Consolidated reserves

Column S (4) processes the investment via the Link account in the same way as before.

The consolidated figures are just the one obtained by horizontal addition.


## Related Topics

- Global integration (>50% control)

---
*Chunk 173 | Explanation*