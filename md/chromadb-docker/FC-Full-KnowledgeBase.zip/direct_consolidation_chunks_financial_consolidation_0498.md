# Chunk 498: Net cash variation

## Context

This section covers Net cash variation.

## Content

### Net cash variation

This is simply the addition of these three cash categories and, as said above, this net amount must be equal to the net variation of Cash and Cash equivalent accounts found in the balance sheet.


---
*Chunk 498 | Net cash variation*