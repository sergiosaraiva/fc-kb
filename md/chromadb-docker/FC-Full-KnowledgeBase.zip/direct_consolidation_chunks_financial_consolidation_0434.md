# Chunk 434: Consolidated Reserves Calculation for B:

## Context

This section explains goodwill calculation in financial consolidation. Shows detailed calculations.

## Content

## Consolidated Reserves Calculation for B:
- **Year 1**: 480 = 48% × (1,000 + 800 + 200) - 80% × 600
- **Year 2**: 445.5 = 81% × (1,500 + 950 + 100) - 90% × 1,800
- **Difference**: (34.5) - considered as goodwill/badwill


## Related Topics

- Goodwill calculation and impairment

---
*Chunk 434 | Consolidated Reserves Calculation for B:*