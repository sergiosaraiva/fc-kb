# Chunk 99: Control Assessment:

## Context

This section describes global integration method for controlled subsidiaries. Discusses relationships between entities: P, A.

## Content

## Control Assessment:
- P controls A (80% majority)
- A controls B (60% majority)
- Full consolidation chain


---
*Chunk 99 | Control Assessment:*