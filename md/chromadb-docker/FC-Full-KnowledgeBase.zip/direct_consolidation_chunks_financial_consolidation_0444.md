# Chunk 444: Context:

## Context

This section addresses foreign currency translation. Discusses relationships between entities: P.

## Content

## Context:
- P owns 90% of A
- A was founded by P a few years ago
- Simple two-company structure
- No consolidation adjustments required for Year 1
- Both companies use same currency


## Related Topics

- Currency translation

---
*Chunk 444 | Context:*