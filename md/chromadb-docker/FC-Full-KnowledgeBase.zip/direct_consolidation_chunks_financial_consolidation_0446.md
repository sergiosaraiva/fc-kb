# Chunk 446: Group Structure - Year 2

## Context

This section covers Group Structure - Year 2.

## Content

# Group Structure - Year 2

```
         Year 2

         ┌─────┐
         │  P  │
         └──┬──┘
           /│\
        70%/ │ \60%
         /   │   \
        ↓    │    ↓
    ┌─────┐ │  ┌─────┐
    │  A  │ │  │  B  │
    └─────┘ │  └─────┘
```


---
*Chunk 446 | Group Structure - Year 2*