# Chunk 458: Period to justify

## Context

This section covers Period to justify.

## Content

## Period to justify

Translation adjustments evolution is justified from one period with regard to the previous closing period. We never justify the evolution since the beginning of the life time of each company in the group. Reference period figures have been audited and the corresponding figures constitute a kind of starting line.


---
*Chunk 458 | Period to justify*