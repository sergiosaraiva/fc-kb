# Chunk 393: Share premium

## Context

This section covers Share premium.

## Content

## Share premium

It is only the parent company share premium that contributes to this line, the share premium from other companies is eliminated against the reserves.

For a consortium, share premium behaves as the capital account, it is the addition of the share premium of the different parent companies.


---
*Chunk 393 | Share premium*