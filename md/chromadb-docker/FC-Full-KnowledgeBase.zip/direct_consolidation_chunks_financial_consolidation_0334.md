# Chunk 334: Let's consider an example

## Context

This section covers Let's consider an example. Includes practical examples.

## Content

### Let's consider an example

We are going to analyse the situation of parent company P acquiring  80%  of shares of company A for a price of 1200 on July  1st . At that date, the equity of A is 860, including a profit of 60 for the first six months of the year.

A due diligence identifies a tangible asset that should be revaluated for an amount of 500, with a  10%  per year depreciation.


---
*Chunk 334 | Let's consider an example*