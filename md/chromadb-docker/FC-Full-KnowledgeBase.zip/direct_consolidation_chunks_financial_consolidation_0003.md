# Chunk 3: PART 1

## Context

This section covers PART 1.

## Content

## PART 1

This introduction takes a look at consolidation over the past decades. It includes some anecdotes which marked the pioneering adventure of the first groups.

Our look at the past reveals an extraordinary evolution, primarily resulting from information technology and the culture of groups rather than from consolidation accounting principles themselves.

We conclude our overview with an attempt to imagine how consolidation and the environment in which it is carried out may continue to change in the future.


---
*Chunk 3 | PART 1*