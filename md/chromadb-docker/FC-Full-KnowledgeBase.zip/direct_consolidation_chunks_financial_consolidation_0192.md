# Chunk 192: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: r, t.

## Content

## Ownership Structure:
- Parent owns 80% of C
- Partner owns 20% of C
- Total: 100% of C


---
*Chunk 192 | Ownership Structure:*