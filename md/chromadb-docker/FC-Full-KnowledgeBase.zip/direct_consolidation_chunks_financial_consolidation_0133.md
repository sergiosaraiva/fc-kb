# Chunk 133: 3.5 Control percentage - Financial percentage

## Context

This section covers 3.5 Control percentage - Financial percentage.

## Content

## 3.5 Control percentage - Financial percentage


---
*Chunk 133 | 3.5 Control percentage - Financial percentage*