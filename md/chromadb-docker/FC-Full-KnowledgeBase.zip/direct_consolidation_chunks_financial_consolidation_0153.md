# Chunk 153: Key Features:

## Context

This section covers Key Features:. Discusses relationships between entities: B.

## Content

## Key Features:
- Cross-participation: B owns 10% of A
- Multiple paths to C (from P, A, and B)
- P is ultimate parent (no incoming ownership)
- C is ultimate subsidiary (no outgoing ownership)


---
*Chunk 153 | Key Features:*