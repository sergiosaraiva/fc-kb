# Chunk 87: Effective Ownership:

## Context

This section explains minority interest calculations.

## Content

## Effective Ownership:
- A's effective control: 60% / 95% = 63.16%
- Minority interests: 35% / 95% = 36.84%


## Related Topics

- Minority interests calculation

---
*Chunk 87 | Effective Ownership:*