# Chunk 353: A spreadsheet view

## Context

This section covers A spreadsheet view. Shows detailed calculations.

## Content

## A spreadsheet view

To summarize what has been done until now, we can use the following 'spreadsheet" picture.


<!-- Source: 768de0f735aa2a803cee6c66ba5a5a5b2061371892105f4212a336d74c0884b1.jpg -->
<!-- Type: table -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T14:55:00 -->
<!-- Context: Consolidation adjustment spreadsheet showing step-by-step process -->
<!-- Section: A spreadsheet view -->


---
*Chunk 353 | A spreadsheet view*