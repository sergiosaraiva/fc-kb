# Chunk 403: Left Structure:

## Context

This section covers Left Structure:. Discusses relationships between entities: P, A.

## Content

### Left Structure:
- P owns 80% of A
- A owns 60% of B
- P's indirect ownership of B: 48% (80% × 60%)


---
*Chunk 403 | Left Structure:*