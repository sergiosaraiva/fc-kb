# Chunk 110: Group with Crossed Participations

## Context

This section covers Group with Crossed Participations.

## Content

# Group with Crossed Participations

```
         ┌─────┐
         │  P  │
         └─┬─┬─┘
          /   \
      80%/     \60%
        /       \
       ↓         ↓
    ┌────┐     ┌────┐
    │ C1 │←────│ C2 │
    └────┘ 20% └────┘
       └──────────┘
           30%
```


---
*Chunk 110 | Group with Crossed Participations*