# Chunk 179: Rationale:

## Context

This section covers Rationale:.

## Content

## Rationale:
- P does not control S (49% < 50%)
- S's assets/liabilities not under P's control
- Only P's share of S's equity is recognized


---
*Chunk 179 | Rationale:*