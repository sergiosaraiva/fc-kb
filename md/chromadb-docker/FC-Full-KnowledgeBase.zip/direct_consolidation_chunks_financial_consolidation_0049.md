# Chunk 49: Control Indicators:

## Context

This section covers Control Indicators:. Key thresholds: control (>50%) triggering global integration.

## Content

## Control Indicators:
- Majority of voting rights (> 50%)
- Power to appoint board majority
- Power over financial and operating policies
- Exposure to variable returns


---
*Chunk 49 | Control Indicators:*