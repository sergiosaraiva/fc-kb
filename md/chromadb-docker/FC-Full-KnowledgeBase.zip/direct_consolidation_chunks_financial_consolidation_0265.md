# Chunk 265: Unmatched intercompany transactions because of capitalization of costs

## Context

This section covers Unmatched intercompany transactions because of capitalization of costs.

## Content

## Unmatched intercompany transactions because of capitalization of costs


---
*Chunk 265 | Unmatched intercompany transactions because of capitalization of costs*