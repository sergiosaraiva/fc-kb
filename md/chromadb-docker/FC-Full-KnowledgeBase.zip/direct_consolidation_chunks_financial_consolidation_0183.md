# Chunk 183: Context:

## Context

This section covers the equity method for 20-50% ownership stakes. Includes practical examples. Shows detailed calculations.

## Content

## Context:
This represents P's statutory accounts before equity method consolidation. The Investment S of 120 will be adjusted to equity value during consolidation (49% of S's equity).
  
Example


<!-- Source: 2ab36a5feb7507a7fbeb76679cbd7e0f18ebfe1d3e11db7217d0539aff8d4054.jpg -->
<!-- Type: table -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T16:23:00 -->
<!-- Context: Equity method example - Company S balance sheet -->
<!-- Section: 4.3 The equity method - Subsidiary company accounts -->


## Related Topics

- Equity method (20-50% ownership)

---
*Chunk 183 | Context:*