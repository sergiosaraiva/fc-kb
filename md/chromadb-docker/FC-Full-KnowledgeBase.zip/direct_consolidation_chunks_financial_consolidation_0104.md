# Chunk 104: Paths to C4:

## Context

This section covers Paths to C4:.

## Content

## Paths to C4:
- Via C1: 80% × 30% = 24%
- Via C2: 60% × 20% = 12%
- Via C3: 40% × (20% + 10%) = 12%
- **Total P's interest in C4**: 48%


---
*Chunk 104 | Paths to C4:*