# Chunk 259: The situation

## Context

This section covers The situation.

## Content

### The situation

Supposing a group that produces consolidated accounts at the end of Year 1, a "cut-off" procedure consists in asking to all group companies not to make transactions any more between them during a certain number of days before the end of the year. The idea behind this organization procedure is to avoid transactions that are booked on one company side but not on the partner side.


---
*Chunk 259 | The situation*