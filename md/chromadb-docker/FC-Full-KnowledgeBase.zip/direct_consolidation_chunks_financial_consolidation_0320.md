# Chunk 320: 8.10 Statutory write-off of a consolidated financial investment

## Context

This section covers 8.10 Statutory write-off of a consolidated financial investment.

## Content

## 8.10 Statutory write-off of a consolidated financial investment


---
*Chunk 320 | 8.10 Statutory write-off of a consolidated financial investment*