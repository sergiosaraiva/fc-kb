# Chunk 417: Financial Investment and Equity Evolution

## Context

This section contains financial statement data.

## Content

# Financial Investment and Equity Evolution

| Account | Description | Year 1 | Year 2 |
|---------|-------------|-------:|-------:|
| **Company A** | | | |
| | Fin. Inv./B | 600 | 1,100 |
| **Company B** | | | |
| | Capital | 1,000 | 1,500 |
| | Reserves | 800 | 950 |
| | Result | 200 | 100 |
| | **Total Equity** | **2,000** | **2,550** |


---
*Chunk 417 | Financial Investment and Equity Evolution*