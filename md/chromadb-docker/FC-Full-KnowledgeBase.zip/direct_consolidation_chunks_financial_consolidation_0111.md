# Chunk 111: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: P.

## Content

## Ownership Structure:
- P owns 80% of C1 (direct)
- P owns 60% of C2 (direct)
- C1 owns 30% of C2 (cross-participation)
- C2 owns 20% of C1 (cross-participation)


---
*Chunk 111 | Ownership Structure:*