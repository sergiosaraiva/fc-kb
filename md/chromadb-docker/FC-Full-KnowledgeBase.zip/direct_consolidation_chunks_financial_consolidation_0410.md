# Chunk 410: Situation 3 : An increase of capital in company B. with percentage variation

## Context

This section covers Situation 3 : An increase of capital in company B. with percentage variation. Shows detailed calculations.

## Content

### Situation 3 : An increase of capital in company B. with percentage variation

In this step, we suppose  3^{rd}  Parties are not willing to subscribe to the capital increase (1 ^{st}  of January, Year 2), which implies a percentage from A in B changing from  60%  to  70% . This new percentage should be calculated on the basis on new shares issues. We skip this calculation.

Here are the new group structure and the corresponding statutory accounts.


<!-- Source: 7babe03f03e2904605dfaf31979de4aa53dff6f63d1c40f6171429e68273f016.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T16:41:00 -->
<!-- Context: Multi-year ownership changes -->
<!-- Section: Ownership percentage evolution -->


---
*Chunk 410 | Situation 3 : An increase of capital in company B. with percentage variation*