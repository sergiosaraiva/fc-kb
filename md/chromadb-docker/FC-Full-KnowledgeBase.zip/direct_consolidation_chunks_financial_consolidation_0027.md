# Chunk 27: Consolidation Considerations:

## Context

This section explains minority interest calculations.

## Content

## Consolidation Considerations:
- Each ownership relationship requires percentage determination
- Different consolidation methods may apply (global, proportional, equity)
- Eliminations needed between group companies
- Minority interests calculation at each level



## Related Topics

- Minority interests calculation
- Elimination entries

---
*Chunk 27 | Consolidation Considerations:*