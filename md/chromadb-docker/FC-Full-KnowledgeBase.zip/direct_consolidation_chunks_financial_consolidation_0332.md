# Chunk 332: 8.13 Acquisition of a company with a goodwill

## Context

This section explains goodwill calculation in financial consolidation.

## Content

## 8.13 Acquisition of a company with a goodwill


## Related Topics

- Goodwill calculation and impairment
- Acquisition accounting

---
*Chunk 332 | 8.13 Acquisition of a company with a goodwill*