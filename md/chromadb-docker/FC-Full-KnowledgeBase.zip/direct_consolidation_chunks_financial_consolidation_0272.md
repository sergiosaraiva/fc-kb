# Chunk 272: The adjustments - Year 1

## Context

This section contains financial statement data.

## Content

## The adjustments - Year 1

At the end of Year 1, we proceed as follows:


| A (Year 1) |  |  |  |
| --- | --- | --- | --- |
| Asset (Acq. Val.) | 110(b) | Capital | 200 |
| Asset (Deprec.) | (11)(a) | Reserves | 0 |
| Cash | (10)c) | Result | (11)(a) |
|   |   |   | (11)(b) |
|   |   |   | (10)(c) |
|   |   |   | (10) |


Adjustment (c): Book an adjustment depreciation of 10 based on the correct value of 100 for that asset


---
*Chunk 272 | The adjustments - Year 1*