# Chunk 481: For Year 1

## Context

This section covers For Year 1. Shows detailed calculations.

## Content

### For Year 1

- Company A:  31 = 10%  (* (200 + 160 + 30 - 80)  
- Company B:  105.8 = 46%  (*  \((100 + 60 + 40 + 30)\)


---
*Chunk 481 | For Year 1*