# Chunk 203: Stage Consolidation Structure

## Context

This section covers Stage Consolidation Structure.

## Content

# Stage Consolidation Structure

```
    ┌─────┐        ┌─────┐        ┌─────┐
    │  P  │───80%──→│  A  │───70%──→│  B  │
    └─────┘        └─────┘        └─────┘
```


---
*Chunk 203 | Stage Consolidation Structure*