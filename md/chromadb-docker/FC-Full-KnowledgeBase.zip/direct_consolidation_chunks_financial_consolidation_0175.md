# Chunk 175: Equity Method - Significant Influence

## Context

This section covers the equity method for 20-50% ownership stakes.

## Content

# Equity Method - Significant Influence

```
    ┌─────┐                    ┌─────┐
    │  P  │───────49%──────────→│  S  │
    └─────┘                    └─────┘
```


## Related Topics

- Equity method (20-50% ownership)

---
*Chunk 175 | Equity Method - Significant Influence*