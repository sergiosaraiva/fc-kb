# Chunk 196: Key Features:

## Context

This section covers Key Features:.

## Content

That specific account that appears in the consolidated accounts must be considered indeed as reserves just like other reserves accounts, because it is accumulation of non-distributed results of each company.


---
*Chunk 196 | Key Features:*