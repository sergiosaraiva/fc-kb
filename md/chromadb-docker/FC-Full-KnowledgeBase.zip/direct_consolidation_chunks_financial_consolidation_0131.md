# Chunk 131: Consolidation Approach:

## Context

This section explains minority interest calculations.

## Content

## Consolidation Approach:
- FP consolidates both A and B groups
- Eliminates cross-holdings between A and B
- Presents unified financial statements
- No minority interests at FP level


## Related Topics

- Minority interests calculation

---
*Chunk 131 | Consolidation Approach:*