# Chunk 412: Year 1

## Context

This section covers Year 1.

## Content

## Year 1
```
    ┌─────┐
    │  P  │
    └──┬──┘
       │ 80%
       ↓
    ┌─────┐
    │  A  │
    └──┬──┘
       │ 60%
       ↓
    ┌─────┐
    │  B  │
    └─────┘
```


---
*Chunk 412 | Year 1*