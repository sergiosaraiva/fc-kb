# Chunk 220: Structure Details:

## Context

This section covers Structure Details:. Discusses relationships between entities: P, A.

## Content

## Structure Details:
- P owns 80% of A (direct)
- A owns 70% of B (direct)
- P's indirect ownership of B: 56% (80% × 70%)


---
*Chunk 220 | Structure Details:*