# Chunk 418: Analysis:

## Context

This section covers Analysis:.

## Content

## Analysis:
- A's investment in B increased from 600 to 1,100 (+500)
- B's capital increased from 1,000 to 1,500 (+500)
- B's reserves increased from 800 to 950 (+150)
- B's result decreased from 200 to 100 (-100)
- B's total equity grew from 2,000 to 2,550 (+550)


---
*Chunk 418 | Analysis:*