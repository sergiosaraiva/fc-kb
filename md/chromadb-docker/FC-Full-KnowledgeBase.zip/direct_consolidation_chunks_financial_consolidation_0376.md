# Chunk 376: Before Restructuring

## Context

This section covers Before Restructuring.

## Content

## Before Restructuring
```
    ┌─────┐
    │  P  │
    └─┬─┬─┘
      │ │
      ↓ ↓
  ┌─────┐ ┌─────┐
  │  A  │ │  B  │
  └─────┘ └─────┘
```


---
*Chunk 376 | Before Restructuring*