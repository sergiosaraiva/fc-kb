# Chunk 276: 8.3 Disposal of an asset between two companies, with a group profit

## Context

This section covers 8.3 Disposal of an asset between two companies, with a group profit.

## Content

# 8.3 Disposal of an asset between two companies, with a group profit


---
*Chunk 276 | 8.3 Disposal of an asset between two companies, with a group profit*