# Chunk 475: Year 1

## Context

This section covers Year 1.

## Content

## Year 1
```
    ┌─────┐
    │  P  │
    └──┬──┘
       │ 90%
       ↓
    ┌─────┐
    │  A  │
    └──┬──┘
       │ 60%
       ↓
    ┌─────┐
    │  B  │
    └─────┘
```


---
*Chunk 475 | Year 1*