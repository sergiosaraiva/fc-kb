# Chunk 84: Treasury Shares Structure

## Context

This section covers Treasury Shares Structure.

## Content

# Treasury Shares Structure

```
    ┌─────┐
    │  A  │────────60%────────→┌─────┐
    └─────┘                     │  B  │←┐
                                └─────┘ │
                                   └────┘
                                     5%
```


---
*Chunk 84 | Treasury Shares Structure*