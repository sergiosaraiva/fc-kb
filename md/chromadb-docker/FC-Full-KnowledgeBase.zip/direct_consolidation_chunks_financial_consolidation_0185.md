# Chunk 185: Key Information:

## Context

This section covers Key Information:. Shows detailed calculations.

## Content

## Key Information:
- Capital: 200
- Total assets: 700
- Liabilities: 300
- Total equity: 400 (700 - 300)
- Balance sheet balances: 700 = 700 ✓


---
*Chunk 185 | Key Information:*