# Chunk 439: 2.3 A status board to justify consolidated reserves evolution

## Context

This section covers 2.3 A status board to justify consolidated reserves evolution.

## Content

# 2.3 A status board to justify consolidated reserves evolution

The situations explained in previous section illustrate the difficulty to validate the evolution of the consolidated reserves of a group and consequently justify the use of some status board to help validation of this technical account.


---
*Chunk 439 | 2.3 A status board to justify consolidated reserves evolution*