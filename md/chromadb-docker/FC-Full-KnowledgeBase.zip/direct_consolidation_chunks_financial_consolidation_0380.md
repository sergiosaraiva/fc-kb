# Chunk 380: Consolidation Impact:

## Context

This section explains minority interest calculations.

## Content

## Consolidation Impact:
- Same entities in scope
- Different elimination entries
- Changed minority interest structure
- Potential tax implications


## Related Topics

- Minority interests calculation
- Elimination entries

---
*Chunk 380 | Consolidation Impact:*