# Chunk 109: Group with crossed participations

## Context

This section covers Group with crossed participations. Shows detailed calculations.

## Content

# Group with crossed participations


<!-- Source: 43ce1a9a8d4923a4084ddda54b2c28ac2c862a0155b22fa75b4d416c88334d41.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T16:53:00 -->
<!-- Context: Group with crossed participations -->
<!-- Section: Complex cross-participation structure -->


---
*Chunk 109 | Group with crossed participations*