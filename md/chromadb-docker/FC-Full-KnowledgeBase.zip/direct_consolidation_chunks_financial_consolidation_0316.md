# Chunk 316: 8.9 Elimination of interim dividends

## Context

This section covers elimination entries in consolidation.

## Content

# 8.9 Elimination of interim dividends


## Related Topics

- Elimination entries
- Dividend elimination

---
*Chunk 316 | 8.9 Elimination of interim dividends*