# Chunk 219: Original Chain Structure

## Context

This section covers Original Chain Structure.

## Content

# Original Chain Structure

```
    ┌─────┐        ┌─────┐        ┌─────┐
    │  P  │───80%──→│  A  │───70%──→│  B  │
    └─────┘        └─────┘        └─────┘
```


---
*Chunk 219 | Original Chain Structure*