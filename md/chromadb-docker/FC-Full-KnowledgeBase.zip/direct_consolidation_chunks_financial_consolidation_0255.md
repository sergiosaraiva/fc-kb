# Chunk 255: Unmatched intercompany transactions because of foreign currencies

## Context

This section covers Unmatched intercompany transactions because of foreign currencies.

## Content

## Unmatched intercompany transactions because of foreign currencies


---
*Chunk 255 | Unmatched intercompany transactions because of foreign currencies*