# Chunk 200: THE CONSOLIDATION TECHNIQUES

## Context

This section covers THE CONSOLIDATION TECHNIQUES. Contains formula: md ========== -->. Discusses relationships between entities: y.

## Content

# THE CONSOLIDATION TECHNIQUES

The structure of a group is often complicated by the fact that not only the parent company owns subsidiaries but that some subsidiaries can own shares in other subsidiaries. A question arises then on how to consolidate such groups. There are basically two techniques to consolidate such groups:

The consolidation by stage.  
The direct consolidation.

<!-- ========== CHUNK 7: DOC0038_pages_7_251127_153522.md ========== -->


---
*Chunk 200 | THE CONSOLIDATION TECHNIQUES*