# Chunk 116: A company owns shares of the parent company

## Context

This section covers A company owns shares of the parent company. Shows detailed calculations. Discusses relationships between entities: y.

## Content

## A company owns shares of the parent company

In this group, company C1 owns  10%  of shares of parent company P.


<!-- Source: 1312117deee444c460538178146d8806453a7278d716d1b0778085740cb45f55.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T16:54:00 -->
<!-- Context: Treasury shares structure -->
<!-- Section: Company owning parent shares -->


---
*Chunk 116 | A company owns shares of the parent company*