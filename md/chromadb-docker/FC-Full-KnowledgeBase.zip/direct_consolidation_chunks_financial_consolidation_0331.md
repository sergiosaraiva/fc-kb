# Chunk 331: What will happen to the badwill in the future?

## Context

This section covers What will happen to the badwill in the future?. Shows detailed calculations.

## Content

### What will happen to the badwill in the future?

If the participation of  80%  remains unchanged, the badwill will stay unchanged in the equity.

No reduction of value is accepted for the badwill.

If company P decides to sell  20%  of its participation in the future, then the group will book  (1/4)  of the badwill into P&L.

If the remaining  20%  can be acquired in the future, the logic of evaluation of a possible badwill is the same and if a new badwill is confirmed, the second one is just added to the first one.


---
*Chunk 331 | What will happen to the badwill in the future?*