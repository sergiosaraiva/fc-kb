# Chunk 141: Calculation of the control percentages

## Context

This section covers Calculation of the control percentages.

## Content

### Calculation of the control percentages

C1 is controlled at  75%  
- C2 is controlled at  80%  because P does not control C3 and therefore the  7%  must be ignored  
C3 is not controlled because  30% < 50%  
C4 is controlled because we have  35%  (P  - > C4  )  +25%  (C1 which is controlled by P). The total control percentage is  60%  
- C5 is controlled at  60% = 35%  (C2 which is controlled by P) +  25%  (C4 which is controlled  \(- > \mathrm{C}5)\) .


---
*Chunk 141 | Calculation of the control percentages*