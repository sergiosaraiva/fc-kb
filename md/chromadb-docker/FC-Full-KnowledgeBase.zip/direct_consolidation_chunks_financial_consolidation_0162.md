# Chunk 162: Consolidation Impact:

## Context

This section explains minority interest calculations. Shows detailed calculations.

## Content

## Consolidation Impact:
- Consolidated reserves (S): 84 (51% × 400 - 120)
- Minority interests in result: 24.5 (49% × 50)
- Group result: 125.5 (100 + 51% × 50)


## Related Topics

- Minority interests calculation

---
*Chunk 162 | Consolidation Impact:*