# Chunk 97: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: P, A.

## Content

## Ownership Structure:
- P owns 80% of A (direct)
- A owns 60% of B (direct)
- P's indirect in B: 48% (80% × 60%)


---
*Chunk 97 | Ownership Structure:*