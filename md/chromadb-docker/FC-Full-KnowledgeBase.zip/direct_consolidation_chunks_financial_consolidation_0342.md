# Chunk 342: Analysis of the selling transaction

## Context

This section covers Analysis of the selling transaction. Includes practical examples.

## Content

## Analysis of the selling transaction

This will be the difficult part of this example and our explanations will consider three different methods, each one of course giving the same consolidation adjustment.


---
*Chunk 342 | Analysis of the selling transaction*