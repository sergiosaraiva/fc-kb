# Chunk 413: Year 2

## Context

This section covers Year 2.

## Content

## Year 2
```
    ┌─────┐
    │  P  │
    └──┬──┘
       │ 80%
       ↓
    ┌─────┐
    │  A  │
    └──┬──┘
       │ 70%
       ↓
    ┌─────┐
    │  B  │
    └─────┘
```


---
*Chunk 413 | Year 2*