# Chunk 64: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: B, A.

## Content

## Ownership Structure:
- A owns 75% of B (direct)
- B owns 90% of C (direct)
- A's indirect in C: 67.5% (75% × 90%)


---
*Chunk 64 | Ownership Structure:*