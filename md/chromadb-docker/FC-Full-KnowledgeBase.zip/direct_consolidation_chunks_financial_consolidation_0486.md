# Chunk 486: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: P, T.

## Content

## Ownership Structure:
- P owns 30% of A
- T owns 70% of A
- Total: 100% of A


---
*Chunk 486 | Ownership Structure:*