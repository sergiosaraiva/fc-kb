# Chunk 86: Treasury Shares Impact:

## Context

This section covers Treasury Shares Impact:.

## Content

## Treasury Shares Impact:
- 5% of B's shares held as treasury
- Effectively reduces shares in circulation
- No voting rights on treasury shares
- Affects EPS calculations


---
*Chunk 86 | Treasury Shares Impact:*