# Chunk 338: 8.14 Disposal of consolidated shares to 3rd Parties

## Context

This section covers 8.14 Disposal of consolidated shares to 3rd Parties.

## Content

# 8.14 Disposal of consolidated shares to 3rd Parties


---
*Chunk 338 | 8.14 Disposal of consolidated shares to 3rd Parties*