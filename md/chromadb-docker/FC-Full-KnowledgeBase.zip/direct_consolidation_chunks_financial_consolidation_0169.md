# Chunk 169: Ownership Details:

## Context

This section covers Ownership Details:. Discusses relationships between entities: P.

## Content

## Ownership Details:
- P owns 50% of S
- Joint control arrangement
- Consolidation method: Proportional integration


---
*Chunk 169 | Ownership Details:*