# Chunk 449: Company B:

## Context

This section covers Company B:.

## Content

### Company B:
- Year 1: Not in group
- Year 2: 60% owned by P
- Change: Newly acquired


---
*Chunk 449 | Company B:*