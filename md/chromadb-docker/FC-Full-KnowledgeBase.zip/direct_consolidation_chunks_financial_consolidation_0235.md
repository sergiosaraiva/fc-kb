# Chunk 235: The notes to the accounts

## Context

This section addresses foreign currency translation.

## Content

## The notes to the accounts

Speaking about the flows, they are also a kind of movie showing different pictures during the consolidation period. Happening during the year, it seems reasonable to also use the same average rate as the one used for the P&L.

Moreover, we should keep in mind that some validations are usually made when receiving the subsidiaries information. For instance, in local currency, the flow corresponding to a new provision booked in the Liabilities should be found as equal to a provision booked in the P&L. Of course, after currency translation, these two amounts should remain equal. This is only possible if we use the same average rate.


## Related Topics

- Currency translation

---
*Chunk 235 | The notes to the accounts*