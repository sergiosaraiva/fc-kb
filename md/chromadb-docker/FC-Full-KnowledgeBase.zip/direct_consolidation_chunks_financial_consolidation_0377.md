# Chunk 377: After Restructuring

## Context

This section covers After Restructuring.

## Content

## After Restructuring
```
        ⟹
```

```
    ┌─────┐
    │  P  │
    └──┬──┘
       │
       ↓
    ┌─────┐
    │  B  │
    └──┬──┘
       │
       ↓
    ┌─────┐
    │  A  │
    └─────┘
```


---
*Chunk 377 | After Restructuring*