# Chunk 66: Minority Interests:

## Context

This section explains minority interest calculations.

## Content

## Minority Interests:
- In B: 25%
- In C: 32.5% (100% - 67.5%)


## Related Topics

- Minority interests calculation

---
*Chunk 66 | Minority Interests:*