# Chunk 324: The situation

## Context

This section covers The situation.

## Content

### The situation

Most groups are producing their consolidated accounts a few weeks after the closing date and sometimes long before the statutory accounts of the subsidiaries. It is indeed not possible to wait for each company to report their accounts after the approval of the shareholders' annual meeting. The consequence is that in the next consolidation we find that the result previously consolidated before is not the final one.

What to do in such situation?


---
*Chunk 324 | The situation*