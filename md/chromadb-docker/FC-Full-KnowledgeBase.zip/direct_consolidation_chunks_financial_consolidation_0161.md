# Chunk 161: Financial Data Given:

## Context

This section explains minority interest calculations.

## Content

## Financial Data Given:
- Investment S in P's books: 120
- S's total equity: 400 (Capital 200 + Reserves 150 + Result 50)
- Minority interests: 49% × 400 = 196


## Related Topics

- Minority interests calculation

---
*Chunk 161 | Financial Data Given:*