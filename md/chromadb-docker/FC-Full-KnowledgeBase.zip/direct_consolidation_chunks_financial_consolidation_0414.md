# Chunk 414: Changes Between Years:

## Context

This section covers Changes Between Years:.

## Content

## Changes Between Years:
- P maintains 80% ownership of A
- A increases ownership of B from 60% to 70%
- Additional 10% acquisition in B by A


## Related Topics

- Acquisition accounting

---
*Chunk 414 | Changes Between Years:*