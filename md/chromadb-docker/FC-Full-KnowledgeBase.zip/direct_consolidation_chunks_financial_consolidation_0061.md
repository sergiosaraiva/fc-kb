# Chunk 61: Consolidation Method:

## Context

This section describes global integration method for controlled subsidiaries.

## Content

## Consolidation Method:
- Global integration
- Full line-by-line consolidation
- Minority interest: 20%


## Related Topics

- Global integration (>50% control)
- Minority interests calculation

---
*Chunk 61 | Consolidation Method:*