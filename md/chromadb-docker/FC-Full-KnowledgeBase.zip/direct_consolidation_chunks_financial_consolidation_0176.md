# Chunk 176: Ownership Details:

## Context

This section covers Ownership Details:. Discusses relationships between entities: P.

## Content

## Ownership Details:
- P owns **49%** of S (significant influence but no control)
- No control (< 50%)


---
*Chunk 176 | Ownership Details:*