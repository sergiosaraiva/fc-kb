# Chunk 88: Consolidation Treatment:

## Context

This section covers Consolidation Treatment:.

## Content

## Consolidation Treatment:
- Eliminate treasury shares from equity
- Adjust ownership percentages
- No dividends on treasury shares
- Disclosure requirements apply


## Related Topics

- Dividend elimination

---
*Chunk 88 | Consolidation Treatment:*