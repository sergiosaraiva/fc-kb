# Chunk 96: Horizontal Chain Structure

## Context

This section covers Horizontal Chain Structure.

## Content

# Horizontal Chain Structure

```
    ┌─────┐         ┌─────┐         ┌─────┐
    │  P  │───80%──→│  A  │───60%──→│  B  │
    └─────┘         └─────┘         └─────┘
```


---
*Chunk 96 | Horizontal Chain Structure*