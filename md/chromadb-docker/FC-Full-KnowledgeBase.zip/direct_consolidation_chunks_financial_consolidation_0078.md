# Chunk 78: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: B, A.

## Content

## Ownership Structure:
- A owns 80% of B (control)
- A owns 8% of C (minority)
- B owns 15% of C (minority)


---
*Chunk 78 | Ownership Structure:*