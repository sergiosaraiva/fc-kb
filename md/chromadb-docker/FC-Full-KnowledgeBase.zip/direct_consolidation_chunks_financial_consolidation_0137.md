# Chunk 137: Complex Cross-Holdings:

## Context

This section covers Complex Cross-Holdings:.

## Content

## Complex Cross-Holdings:
- Circular ownership: C1 → C4 → C1
- Cross-participation: C3 → C2
- Multiple paths to C5 (via C2 and C4)


---
*Chunk 137 | Complex Cross-Holdings:*