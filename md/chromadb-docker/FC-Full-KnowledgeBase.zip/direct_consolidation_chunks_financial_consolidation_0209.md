# Chunk 209: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: P, B, A.

## Content

## Ownership Structure:
- P owns 80% of A (direct)
- A owns 60% of B (direct)
- B owns 10% of A (cross-participation)


---
*Chunk 209 | Ownership Structure:*