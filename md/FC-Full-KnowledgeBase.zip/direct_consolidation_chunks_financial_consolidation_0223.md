# Chunk 223: Next Step:

## Context

This section covers Next Step:. Shows detailed calculations.

## Content

## Next Step:
Transform to rake structure where P directly consolidates both A (80%) and B (56%), eliminating the need for step-by-step consolidation through the chain.


which is transformed into a kind of a "rake" structure just as if each company would be owned directly by the parent company.


<!-- Source: eb8fc9ea80aab271940eb6f0a411c6bbd8aef3d87a035322cc3f2a8f38c67482.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T15:30:00 -->
<!-- Context: Direct consolidation technique - "rake" structure transformation -->
<!-- Section: 2.3 Direct consolidation method -->


---
*Chunk 223 | Next Step:*