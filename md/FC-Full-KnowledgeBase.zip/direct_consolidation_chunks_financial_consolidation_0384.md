# Chunk 384: 1.2 Flows and consolidation process

## Context

This section covers 1.2 Flows and consolidation process.

## Content

## 1.2 Flows and consolidation process

Flows are submitted to the consolidation process in a similar way as are the balance accounts.


---
*Chunk 384 | 1.2 Flows and consolidation process*