# Chunk 39: First caleoiv example: "Compliance to evaluation rules" adjustments

## Context

This section covers First caleoiv example: "Compliance to evaluation rules" adjustments. Includes practical examples.

## Content

## First caleoiv example: "Compliance to evaluation rules" adjustments

For some fiscal reasons, a company A depreciates a fixed asset over 5 years but the group rules specify to depreciate this asset over 10 years.

What is the impact in the consolidation?

- First we have to reverse the statutory depreciation based over 5 years  
Book a new depreciation based over 10 years  
Calculate deferred taxes (certainly if IFRS)

and don't forget to check at each consolidation that the asset being adjusted is still in the account of the company!


---
*Chunk 39 | First caleoiv example: "Compliance to evaluation rules" adjustments*