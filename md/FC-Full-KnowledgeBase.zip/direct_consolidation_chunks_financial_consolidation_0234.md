# Chunk 234: The P&L accounts

## Context

This section covers The P&L accounts.

## Content

## The P&L accounts

The P&L is not a picture. It is a movie. To give a correct economical picture of it, one should translate all income and expenses of January 1 at the rate of that date, and all income and expenses of January 2 at the rate of that second date, and so on until the end of the period. Very difficult to apply!

A much more realistic approach consists in using an average rate over the twelve months of the year. Usually, this average rate is the arithmetic mean of the twelve monthly closing rates of the period.


---
*Chunk 234 | The P&L accounts*