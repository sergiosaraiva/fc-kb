# Chunk 415: Indirect Ownership:

## Context

This section covers Indirect Ownership:. Contains formula: s indirect in B = 48% (80% × 60%).

## Content

## Indirect Ownership:
- **Year 1**: P's indirect in B = 48% (80% × 60%)
- **Year 2**: P's indirect in B = 56% (80% × 70%)


---
*Chunk 415 | Indirect Ownership:*