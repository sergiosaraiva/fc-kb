# Chunk 92: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: t.

## Content

## Ownership Structure:
- Parent owns 80% of Subsidiary
- Clear control relationship


---
*Chunk 92 | Ownership Structure:*