# Chunk 58: Simple Direct Ownership

## Context

This section covers Simple Direct Ownership.

## Content

# Simple Direct Ownership

```
    ┌─────┐                ┌─────┐
    │  A  │──────80%──────→│  B  │
    └─────┘                └─────┘
```


---
*Chunk 58 | Simple Direct Ownership*