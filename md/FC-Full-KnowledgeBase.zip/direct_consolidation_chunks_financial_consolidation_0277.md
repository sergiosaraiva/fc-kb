# Chunk 277: The situation

## Context

This section covers The situation. Contains formula: this asset whose net value is now  210 = 300 - 3*30  is sold to group company B for a price of 280, . Shows detailed calculations.

## Content

## The situation

Three years ago, company A acquired a tangible asset for a price of 300 depreciated by 30 over a period of 10 years. This year (let's call it Year 1), this asset whose net value is now  210 = 300 - 3*30  is sold to group company B for a price of 280, giving a gain of 70 for company A. Company B decides to depreciate the asset over the remaining economical period of 7 years with an annual depreciation of  40 = 280 / 7 .

During Year 2, that asset remains in company B and its net value is  200 = 280 - 2 * 40 .

Beginning of Year 3, company B decides to sell that asset to  3^{rd}  Parties for a price of 260, making a gain of 60.

What will be the impact of this transaction on the consolidated accounts?


---
*Chunk 277 | The situation*