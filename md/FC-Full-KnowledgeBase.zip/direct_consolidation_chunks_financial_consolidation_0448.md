# Chunk 448: Company A:

## Context

This section covers Company A:.

## Content

### Company A:
- Year 1: 90% owned by P
- Year 2: 70% owned by P
- Change: Sold 20% to third parties


---
*Chunk 448 | Company A:*