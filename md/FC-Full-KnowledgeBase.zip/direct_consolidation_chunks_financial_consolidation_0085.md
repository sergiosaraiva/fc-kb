# Chunk 85: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: B, A.

## Content

## Ownership Structure:
- A owns 60% of B (control)
- B owns 5% of its own shares (treasury shares)


---
*Chunk 85 | Ownership Structure:*