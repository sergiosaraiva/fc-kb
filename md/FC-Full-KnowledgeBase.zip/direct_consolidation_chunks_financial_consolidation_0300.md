# Chunk 300: The situation

## Context

This section covers The situation.

## Content

- In consolidation, we always consider the gross dividend, whatever the net dividend received because of local taxes  
- At the end of each year, we consolidate accounts before any appropriation. This is an organizational requirement because it wouldn't be acceptable to wait for the final audited accounts approved by the general annual meeting. Consolidated figures would be closed to late.

This group will be consolidated by the global method with a financial percentage of  80%  for each of the two years.


## Related Topics

- Dividend elimination

---
*Chunk 300 | The situation*