# Chunk 443: Group Structure - Year 1

## Context

This section covers Group Structure - Year 1.

## Content

# Group Structure - Year 1

```
    Year 1

    ┌─────┐
    │  P  │
    └──┬──┘
       │ 90%
       ↓
    ┌─────┐
    │  A  │
    └─────┘
```


---
*Chunk 443 | Group Structure - Year 1*