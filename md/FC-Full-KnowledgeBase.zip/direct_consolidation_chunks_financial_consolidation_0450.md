# Chunk 450: Transaction Details:

## Context

This section addresses foreign currency translation.

## Content

## Transaction Details:
- Both transactions occurred on January 1st, Year 2
- Sale of A shares and acquisition of B simultaneous
- All companies use same currency
- Impacts consolidated reserves calculation



## Related Topics

- Currency translation
- Acquisition accounting

---
*Chunk 450 | Transaction Details:*