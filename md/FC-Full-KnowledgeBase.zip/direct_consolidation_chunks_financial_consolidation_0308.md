# Chunk 308: The situation

## Context

This section addresses foreign currency translation.

## Content

## The situation

The situation is similar to the previous one, except for company A whose accounts are in a certain foreign currency CUR. That company is owned by the parent company P with a financial percentage of  80%  over Year 1 and Year 2.

At the end of Year 1, company A pays a gross dividend of 100 EUR to the shareholders while P pays a gross dividend of 150 EUR.


## Related Topics

- Dividend elimination
- Currency translation

---
*Chunk 308 | The situation*