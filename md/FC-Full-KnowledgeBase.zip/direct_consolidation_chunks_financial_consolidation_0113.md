# Chunk 113: Effective Ownership Calculation:

## Context

This section covers Effective Ownership Calculation:.

## Content

## Effective Ownership Calculation:
- Complex due to circular references
- Must solve simultaneous equations
- Consider treasury share treatment


---
*Chunk 113 | Effective Ownership Calculation:*