# Chunk 189: 4.4 Consolidated reserves of a company

## Context

This section covers 4.4 Consolidated reserves of a company. Contains formula: Consolidated reserves = financial indirect  %  equity of S - Investment in P. Discusses relationships between entities: y.

## Content

## 4.4 Consolidated reserves of a company

Consolidated reserves are the difference between the indirect percentage held in the equity of a subsidiary and the value of the investment that the parent company owns on this subsidiary.

Consolidated reserves = financial indirect  %  equity of S - Investment in P


---
*Chunk 189 | 4.4 Consolidated reserves of a company*