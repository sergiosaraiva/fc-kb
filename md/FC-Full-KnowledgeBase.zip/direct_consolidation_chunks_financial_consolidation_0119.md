# Chunk 119: Treasury Share Impact:

## Context

This section covers Treasury Share Impact:.

## Content

## Treasury Share Impact:
- C1's 10% stake in P creates circular ownership
- Often treated as treasury shares in consolidation
- Reduces effective share capital in circulation


---
*Chunk 119 | Treasury Share Impact:*