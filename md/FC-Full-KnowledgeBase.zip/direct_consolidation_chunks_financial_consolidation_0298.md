# Chunk 298: 8.7 Elimination of dividends in a classical situation

## Context

This section covers elimination entries in consolidation.

## Content

# 8.7 Elimination of dividends in a classical situation


## Related Topics

- Elimination entries
- Dividend elimination

---
*Chunk 298 | 8.7 Elimination of dividends in a classical situation*