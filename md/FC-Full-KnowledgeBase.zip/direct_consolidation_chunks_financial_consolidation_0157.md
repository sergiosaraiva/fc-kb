# Chunk 157: Example

## Context

This section describes global integration method for controlled subsidiaries. Includes practical examples. Shows detailed calculations.

## Content

### Example


<!-- Source: 23c9b8b57c857e018aaa9eb5298f1a9e810912a9a009d69a621bc2a17f2fa0ec.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T16:17:00 -->
<!-- Context: Global integration method example -->
<!-- Section: 4.1 The consolidation methods - Global integration -->


## Related Topics

- Global integration (>50% control)

---
*Chunk 157 | Example*