# Chunk 130: Consortium Characteristics:

## Context

This section covers Consortium Characteristics:.

## Content

## Consortium Characteristics:
- A and B operate as joint parents
- FP created for consolidation purposes only
- No actual ownership by FP
- Represents combined control by A and B


---
*Chunk 130 | Consortium Characteristics:*