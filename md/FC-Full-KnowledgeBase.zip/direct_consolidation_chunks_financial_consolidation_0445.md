# Chunk 445: Upcoming Changes (Year 2):

## Context

This section covers Upcoming Changes (Year 2):. Shows detailed calculations.

## Content

## Upcoming Changes (Year 2):
- P will sell 20% of A shares to third parties (90% → 70%)
- P will acquire 60% of company B
- Both transactions on January 1st, Year 2



<!-- Source: 92f5d91962a1e2beeb48dc423111236babbaf02d671c5be5eee0d3e02c8e4e24.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T15:14:00 -->
<!-- Context: Consolidated reserves status board case study - Year 2 -->
<!-- Section: 2.4 Group structure after transactions -->


---
*Chunk 445 | Upcoming Changes (Year 2):*