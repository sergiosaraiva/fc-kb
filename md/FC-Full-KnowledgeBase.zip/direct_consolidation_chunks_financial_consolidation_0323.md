# Chunk 323: 8.11 Difference on opening reserves

## Context

This section covers 8.11 Difference on opening reserves.

## Content

## 8.11 Difference on opening reserves


---
*Chunk 323 | 8.11 Difference on opening reserves*