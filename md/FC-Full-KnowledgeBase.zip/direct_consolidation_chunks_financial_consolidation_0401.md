# Chunk 401: Ownership Structure Comparison - Year 2 Scenarios

## Context

This section covers Ownership Structure Comparison - Year 2 Scenarios.

## Content

# Ownership Structure Comparison - Year 2 Scenarios

```
       Year 2                    Year 2

    ┌─────┐                   ┌─────┐
    │  P  │                   │  P  │
    └──┬──┘                   └──┬──┘
       │80%                      │80%
       ↓                         ↓
    ┌─────┐                   ┌─────┐
    │  A  │                   │  A  │
    └──┬──┘                   └──┬──┘
       │60%                      │50%
       ↓                         ↓
    ┌─────┐                   ┌─────┐
    │  B  │                   │  B  │
    └─────┘                   └─────┘
```


---
*Chunk 401 | Ownership Structure Comparison - Year 2 Scenarios*