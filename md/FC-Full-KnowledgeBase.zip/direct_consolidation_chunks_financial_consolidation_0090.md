# Chunk 90: 3.2 The financial percentage

## Context

This section covers 3.2 The financial percentage. Shows detailed calculations. Discusses relationships between entities: y.

## Content

## 3.2 The financial percentage

In the most general case, when the parent company owns directly  80%  of shares in a subsidiary, each share being supposed to give a right to a dividend, we speak about a financial percentage. Of course, most of the time, that financial percentage is equal to the direct control percentage.


<!-- Source: 8c2a5c54e162a0d056931fe85b9c2f7902adb32169cfff36056c838edafb7577.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T17:13:00 -->
<!-- Context: Basic parent-subsidiary relationship -->
<!-- Section: Fundamental consolidation structure -->


## Related Topics

- Dividend elimination

---
*Chunk 90 | 3.2 The financial percentage*