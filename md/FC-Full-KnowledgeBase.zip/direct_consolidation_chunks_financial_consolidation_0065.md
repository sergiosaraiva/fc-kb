# Chunk 65: Control Chain:

## Context

This section describes global integration method for controlled subsidiaries. Discusses relationships between entities: B, A.

## Content

## Control Chain:
- A controls B (75% majority)
- B controls C (90% strong majority)
- Full consolidation throughout


---
*Chunk 65 | Control Chain:*