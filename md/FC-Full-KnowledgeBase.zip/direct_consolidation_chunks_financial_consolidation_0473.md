# Chunk 473: 4.3 Case study

## Context

This section explains minority interest calculations. Shows detailed calculations.

## Content

## 4.3 Case study

In this group, we are going to produce a justification of the Minority interests evolution for companies A and B which is a foreign company.

For Year 1, the  3^{rd}  Parties percentages are  10%  in A and  46% = 100% - 90% \times 60%  in B.

For Year 2, we find  40%  in A and  58% = 100% - 60% * 70%  in B.

Moreover, we will restrict our view on the necessary accounts, without making a complete consolidation.


<!-- Source: c20b49d1167070016fdc3f7f86548e0701873edac9ba42b80d0fd9b7218a5df3.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T17:03:00 -->
<!-- Context: Two-year ownership evolution -->
<!-- Section: Multi-period ownership changes -->


## Related Topics

- Minority interests calculation

---
*Chunk 473 | 4.3 Case study*