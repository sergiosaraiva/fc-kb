# Chunk 215: Effective Ownership Calculations:

## Context

This section explains minority interest calculations.

## Content

## Effective Ownership Calculations:
- P's total in B: 10% (direct) + 48% (via A) = 58%
- Circular holding requires iterative calculation
- B's stake in A affects minority interests


## Related Topics

- Minority interests calculation

---
*Chunk 215 | Effective Ownership Calculations:*