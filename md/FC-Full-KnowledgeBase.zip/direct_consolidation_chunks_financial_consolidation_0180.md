# Chunk 180: Financial Impact:

## Context

This section covers the equity method for 20-50% ownership stakes. Includes practical examples. Shows detailed calculations.

## Content

## Financial Impact:
- Investment recorded at: 49% × S's total equity
- P&L shows: 49% × S's result as equity income



<!-- Source: b49d9a805558e2dbaf894aa786e15a77548850125071062bd174b5bd76028f2f.jpg -->
<!-- Type: table -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T16:21:00 -->
<!-- Context: Equity method example - Company P balance sheet -->
<!-- Section: 4.3 The equity method - Parent company accounts -->


## Related Topics

- Equity method (20-50% ownership)

---
*Chunk 180 | Financial Impact:*