# Chunk 468: Currency translation of Year 2

## Context

This section addresses foreign currency translation. Contains formula: on result

Year 2 result of  30 = 30^{\star}  (14 - 13). Shows detailed calculations.

## Content

For the currency translation adjustment (CTA) on variations

Capital increase of  \(100 = 50 * (14 - 12)\)

For the currency translation adjustment (CTA) on result

Year 2 result of  30 = 30^{\star}  (14 - 13)


## Related Topics

- Currency translation

---
*Chunk 468 | Currency translation of Year 2*