# Chunk 222: Indirect Financial Percentages:

## Context

This section covers Indirect Financial Percentages:.

## Content

## Indirect Financial Percentages:
- **A**: 80% (direct from P)
- **B**: 56% (indirect: 80% × 70%)


---
*Chunk 222 | Indirect Financial Percentages:*