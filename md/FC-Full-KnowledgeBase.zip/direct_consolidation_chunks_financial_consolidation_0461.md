# Chunk 461: 3.2 Variation analysis from a theoretical point of view

## Context

This section addresses foreign currency translation.

## Content

## 3.2 Variation analysis from a theoretical point of view

The idea is to produce a status board showing, for each foreign company, the effect of rates variations on equity and financial investments accounts.

Beforehand, it seems to us useful to explain some currency translation mechanisms.


## Related Topics

- Currency translation

---
*Chunk 461 | 3.2 Variation analysis from a theoretical point of view*