# Chunk 346: Method 3 : A direct approach

## Context

This section contains financial statement data.

## Content

## Method 3 : A direct approach

We would advise not to use only this method without checking the result with one of the two first methods or both.

We have seen that the consolidated reserves at the end of June Year 2, attached to the  20%  shares disposed, were equal to 170. This accumulated profit has to be reversed by using the following adjustment


|   | Debit | Credit |
| :--- | :--- | :--- |
| Gain on disposal | 170 |   |
| Consolidated reserves |   | 170 |



---
*Chunk 346 | Method 3 : A direct approach*