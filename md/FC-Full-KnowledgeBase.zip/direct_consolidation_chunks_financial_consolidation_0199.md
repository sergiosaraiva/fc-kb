# Chunk 199: 4.6 The value of a company from a consolidation point of view

## Context

This section covers the equity method for 20-50% ownership stakes.

## Content

But, at this moment, don't get confused when we speak about the equity value of a company, even if this company is not consolidated by the equity method. This is just a wording convention.


## Related Topics

- Equity method (20-50% ownership)

---
*Chunk 199 | 4.6 The value of a company from a consolidation point of view*