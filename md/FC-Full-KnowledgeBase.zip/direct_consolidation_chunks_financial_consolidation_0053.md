# Chunk 53: Ownership Structure:

## Context

This section covers Ownership Structure:. Discusses relationships between entities: C, A.

## Content

## Ownership Structure:
- A owns 40% of B
- Public shareholders own 25% of B
- C owns 35% of B
- Total: 100% of B


---
*Chunk 53 | Ownership Structure:*