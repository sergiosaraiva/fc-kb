# Chunk 91: Basic Parent-Subsidiary Structure

## Context

This section covers Basic Parent-Subsidiary Structure.

## Content

# Basic Parent-Subsidiary Structure

```
    ┌────────┐           ┌────────────┐
    │ Parent │────80%───→│ Subsidiary │
    └────────┘           └────────────┘
```


---
*Chunk 91 | Basic Parent-Subsidiary Structure*