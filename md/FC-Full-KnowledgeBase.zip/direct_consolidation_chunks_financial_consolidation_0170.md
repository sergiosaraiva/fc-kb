# Chunk 170: Context:

## Context

This section explains minority interest calculations.

## Content

## Context:
This represents a joint venture where:
- Assets, liabilities, income, and expenses of S are included at 50%
- No minority interests (proportional method)
- Only group's share is consolidated


## Related Topics

- Minority interests calculation

---
*Chunk 170 | Context:*