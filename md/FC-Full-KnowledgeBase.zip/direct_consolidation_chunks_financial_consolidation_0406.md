# Chunk 406: Key Formula:

## Context

This section covers Key Formula:.

## Content

## Key Formula:
Consolidated reserves (B) = %(C) × Equity - %(S) × Financial Investment


---
*Chunk 406 | Key Formula:*