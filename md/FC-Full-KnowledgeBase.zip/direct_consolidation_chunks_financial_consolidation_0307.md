# Chunk 307: 8.8 Elimination of dividends paid by a foreign company

## Context

This section covers elimination entries in consolidation.

## Content

# 8.8 Elimination of dividends paid by a foreign company


## Related Topics

- Elimination entries
- Dividend elimination

---
*Chunk 307 | 8.8 Elimination of dividends paid by a foreign company*