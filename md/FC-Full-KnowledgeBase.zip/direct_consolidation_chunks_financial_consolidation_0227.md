# Chunk 227: Consolidated Balance Sheet Result:

## Context

This section contains financial statement data.

## Content

## Consolidated Balance Sheet Result:

| P + A + B | | Amount |
|-----------|----------|--------|
| | Capital | 500 |
| | Reserves | 150 |
| | Result | 30 |
| | Conso. Res. (A) | 144 |
| | Conso. Res. (B) | 9.6 |
| | Minor. Inter. (A) | 56 |
| | Minor. Inter. (B) | 70.4 |
| Assets | | 1,400 |
| | Liabilities | 440 |
| **Total** | | **1,400** |


---
*Chunk 227 | Consolidated Balance Sheet Result:*