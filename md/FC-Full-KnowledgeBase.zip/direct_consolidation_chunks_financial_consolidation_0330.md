# Chunk 330: The adjustments

## Context

This section covers The adjustments.

## Content

A final check can be done on the consolidated reserves because if we go back to the definition, it is the accumulated profit contributed by company A since its life time in the group. Company A indeed, has belonged to the group only for the last six months of this first year, making a profit of  \(30 = 50 + (20)\) . The group has  80%  of that profit, that is 24.


---
*Chunk 330 | The adjustments*