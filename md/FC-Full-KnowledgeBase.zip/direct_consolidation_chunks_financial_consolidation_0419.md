# Chunk 419: Investment Coverage:

## Context

This section covers Investment Coverage:. Contains formula: Equity = 600/2,000 = 30%. Shows detailed calculations.

## Content

## Investment Coverage:
- **Year 1**: Investment/Equity = 600/2,000 = 30%
- **Year 2**: Investment/Equity = 1,100/2,550 = 43.1%


---
*Chunk 419 | Investment Coverage:*