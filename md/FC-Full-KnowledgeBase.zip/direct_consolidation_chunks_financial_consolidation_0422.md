# Chunk 422: Situation 5 : Company P acauires new shares of company A

## Context

This section covers Situation 5 : Company P acauires new shares of company A. Shows detailed calculations.

## Content

### Situation 5 : Company P acauires new shares of company A

The change in structure is now happening above company B.

It is company P acquiring  10%  of company A shares, on the  1^{st}  of January Year 2, giving a percentage of  90%  from P in A.

When we consider B situation, nothing has changed.


<!-- Source: 6f02bb1740e04d53f26747919037e6d5d9415a03324d0b762feb5f8719fa925b.jpg -->
<!-- Type: diagram -->
<!-- Confidence: high -->
<!-- Converted: 2024-11-28T16:43:00 -->
<!-- Context: Ownership percentage changes over time -->
<!-- Section: Multi-year ownership evolution -->


---
*Chunk 422 | Situation 5 : Company P acauires new shares of company A*