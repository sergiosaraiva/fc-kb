# Chunk 147: Complex Features:

## Context

This section covers Complex Features:.

## Content

## Complex Features:
- Cross-participation between A and B
- Multiple paths from P to C
- C holds 10% of its own shares


---
*Chunk 147 | Complex Features:*