# Chunk 146: Ownership Structure:

## Context

This section covers Ownership Structure:.

## Content

## Ownership Structure:
- P → A: 80% (direct)
- P → B: 60% (direct)
- B → A: 10% (cross-participation)
- A → C: 40% (direct)
- B → C: 20% (direct)
- C → C: 10% (treasury shares)


---
*Chunk 146 | Ownership Structure:*