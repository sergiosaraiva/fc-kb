# Chunk 82: Key Points:

## Context

This section covers the equity method for 20-50% ownership stakes.

## Content

## Key Points:
- Multiple paths to same entity (C)
- Combination of direct and indirect holdings
- Below control threshold for C
- Requires careful calculation of combined interests


When there is a significant influence, the consolidation method to be used is the equity method.


## Related Topics

- Equity method (20-50% ownership)

---
*Chunk 82 | Key Points:*