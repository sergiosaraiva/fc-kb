# Chunk 129: Structure Details:

## Context

This section covers Structure Details:.

## Content

## Structure Details:
- **FP**: Fictitious Parent (consolidation construct)
- **A and B**: Consortium partners (peer companies)
- **A1, A2**: Subsidiaries of A
- **B1, B2**: Subsidiaries of B


---
*Chunk 129 | Structure Details:*