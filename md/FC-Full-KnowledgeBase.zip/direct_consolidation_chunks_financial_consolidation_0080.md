# Chunk 80: Control Assessment:

## Context

This section covers Control Assessment:. Discusses relationships between entities: A.

## Content

## Control Assessment:
- A controls B (80% majority)
- A has 20% total interest in C (significant influence)
- C not controlled by A group


---
*Chunk 80 | Control Assessment:*