# Chunk 181: Company P - Balance Sheet

## Context

This section contains financial statement data.

## Content

# Company P - Balance Sheet

| **P** | | | |
|-------|------:|------------|------:|
| Investments S | 120 | Capital | |
| | | Reserves | |
| | | Result | |
| Assets | 1,030 | Liabilities | |
| **Total** | **1,150** | **Total** | **1,150** |


---
*Chunk 181 | Company P - Balance Sheet*