# Chunk 193: Control Analysis:

## Context

This section covers Control Analysis:.

## Content

## Control Analysis:
- Parent has majority control (80%)
- Partner has minority stake (20%)
- Parent likely consolidates C globally


---
*Chunk 193 | Control Analysis:*