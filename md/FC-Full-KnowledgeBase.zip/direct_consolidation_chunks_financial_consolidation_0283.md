# Chunk 283: 8.4 Elimination of stocks margins

## Context

This section covers elimination entries in consolidation.

## Content

# 8.4 Elimination of stocks margins


## Related Topics

- Elimination entries

---
*Chunk 283 | 8.4 Elimination of stocks margins*