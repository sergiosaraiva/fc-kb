# Chunk 497: Cash from financial activities

## Context

This section covers Cash from financial activities.

## Content

### Cash from financial activities

This category includes all transactions that are not current. Amongst these transactions, we list hereunder the main items

Capital increase/decrease (in cash)  
New long term loans  
- Reimbursement of long term loans  
Grants received  
Dividends paid to shareholders


## Related Topics

- Dividend elimination

---
*Chunk 497 | Cash from financial activities*