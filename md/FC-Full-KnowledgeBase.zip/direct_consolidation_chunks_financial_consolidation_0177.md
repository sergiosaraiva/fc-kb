# Chunk 177: Consolidation Method:

## Context

This section covers the equity method for 20-50% ownership stakes.

## Content

## Consolidation Method:
- **Equity method** (no control but significant influence)
- Assets and liabilities of S are NOT consolidated
- Investment shown at equity value
- No minority interests (equity method)


## Related Topics

- Equity method (20-50% ownership)
- Minority interests calculation

---
*Chunk 177 | Consolidation Method:*