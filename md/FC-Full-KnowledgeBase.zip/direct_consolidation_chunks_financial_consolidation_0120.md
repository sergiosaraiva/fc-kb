# Chunk 120: Consolidation Treatment:

## Context

This section covers Consolidation Treatment:.

## Content

## Consolidation Treatment:
- Eliminate C1's investment in P
- Adjust shareholders' equity for treasury shares
- No voting rights for C1's stake in P
- Affects earnings per share calculations


---
*Chunk 120 | Consolidation Treatment:*