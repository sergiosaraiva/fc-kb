# Chunk 266: The situation

## Context

This section contains financial statement data.

## Content

### The situation

A company A charges intellectual services to company B that decides to capitalize them in the Intangible Assets, which is accepted by the group's procedures.


| A |  |  |  |
| --- | ---: | --- | ---: |
| Receivables/B | 100 | Result | 100 |
| Result | 100 | Sales/B | 100 |



| B |  |
| --- | --- |
| Intangible assets | 100 Pa ables A Payables/A 100 |
|   |   |


Here is the situation showing matched intercompany amounts in the balance sheet but a problem at P&L level.


---
*Chunk 266 | The situation*